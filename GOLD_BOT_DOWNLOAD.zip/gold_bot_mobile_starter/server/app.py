import os
import time
import secrets
from typing import Optional
from fastapi import FastAPI, Header, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

API_KEY = os.getenv("GOLDBOT_API_KEY", "")
if len(API_KEY) < 24:
    raise RuntimeError("Set GOLDBOT_API_KEY to a random secret of at least 24 characters")

app = FastAPI(title="GoldBot Mobile API", version="0.1-demo")

state = {
    "enabled": False,
    "symbol": "XAUUSD.sd",
    "timeframe": "M1",
    "balance": None,
    "equity": None,
    "profit": None,
    "last_signal": "NONE",
    "last_update": 0,
    "message": "Waiting for MT5 EA",
}

class Status(BaseModel):
    symbol: str
    balance: float
    equity: float
    profit: float
    last_signal: str = "NONE"
    message: str = ""

def auth(x_api_key: Optional[str]):
    if not x_api_key or not secrets.compare_digest(x_api_key, API_KEY):
        raise HTTPException(status_code=401, detail="Unauthorized")

@app.get("/health")
def health():
    return {"ok": True, "service": "goldbot-demo"}

@app.get("/control")
def get_control(x_api_key: Optional[str] = Header(default=None)):
    auth(x_api_key)
    return {"enabled": state["enabled"], "symbol": state["symbol"]}

@app.post("/control/{action}")
def set_control(action: str, x_api_key: Optional[str] = Header(default=None)):
    auth(x_api_key)
    if action not in ("start", "stop"):
        raise HTTPException(status_code=400, detail="Action must be start or stop")
    state["enabled"] = action == "start"
    state["message"] = "Started from mobile" if state["enabled"] else "Stopped from mobile"
    return {"ok": True, "enabled": state["enabled"]}

@app.get("/status")
def get_status(x_api_key: Optional[str] = Header(default=None)):
    auth(x_api_key)
    return state

@app.post("/status")
def update_status(payload: Status, x_api_key: Optional[str] = Header(default=None)):
    auth(x_api_key)
    state.update(payload.model_dump())
    state["last_update"] = int(time.time())
    return {"ok": True}

# Installable phone-first web app; serve only behind HTTPS in production.
app.mount("/app", StaticFiles(directory="static", html=True), name="mobile-app")
