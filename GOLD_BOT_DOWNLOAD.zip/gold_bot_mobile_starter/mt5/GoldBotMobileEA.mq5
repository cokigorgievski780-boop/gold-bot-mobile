#property strict
#property version "0.10"
#property description "GoldBot Mobile DEMO EA - EMA 9/21 crossover with mobile START/STOP"

#include <Trade/Trade.mqh>
CTrade trade;

input string InpApiBase = "http://127.0.0.1:8000";
input string InpApiKey = "CHANGE_TO_SAME_LONG_RANDOM_SECRET";
input string InpSymbol = "XAUUSD.sd";
input double InpLots = 0.01;
input double InpTakeProfitMoney = 0.20;
input double InpStopLossMoney = 1.00;
input double InpDailyLossLimit = 2.00;
input int InpFastEMA = 9;
input int InpSlowEMA = 21;
input int InpMagic = 261030;
input int InpPollSeconds = 5;
input int InpMaxSpreadPoints = 100;
input bool InpDemoOnly = true;

int fastHandle = INVALID_HANDLE, slowHandle = INVALID_HANDLE;
bool tradingEnabled = false;
datetime lastBar = 0;
int dayOfYear = -1;
double dayStartEquity = 0;

string Url(string path) { return InpApiBase + path; }

bool HttpGet(string path, string &result)
{
   char data[], response[];
   string headers = "X-API-Key: " + InpApiKey + "\r\n";
   string responseHeaders;
   ResetLastError();
   int code = WebRequest("GET", Url(path), headers, 5000, data, response, responseHeaders);
   if(code == -1) { Print("WebRequest GET failed: ", GetLastError()); return false; }
   result = CharArrayToString(response);
   return (code >= 200 && code < 300);
}

bool HttpPost(string path, string body, string &result)
{
   char data[], response[];
   StringToCharArray(body, data, 0, WHOLE_ARRAY, CP_UTF8);
   string headers = "Content-Type: application/json\r\nX-API-Key: " + InpApiKey + "\r\n";
   string responseHeaders;
   ResetLastError();
   int code = WebRequest("POST", Url(path), headers, 5000, data, response, responseHeaders);
   if(code == -1) { Print("WebRequest POST failed: ", GetLastError()); return false; }
   result = CharArrayToString(response);
   return (code >= 200 && code < 300);
}

bool JsonEnabled(string json)
{
   return (StringFind(json, "\"enabled\":true") >= 0);
}

double MoneyToPriceDistance(double money, double lots)
{
   double tickValue = SymbolInfoDouble(InpSymbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize = SymbolInfoDouble(InpSymbol, SYMBOL_TRADE_TICK_SIZE);
   if(tickValue <= 0 || tickSize <= 0 || lots <= 0) return 0;
   return (money / (tickValue * lots)) * tickSize;
}

double NormalizeVolume(double volume)
{
   double minv = SymbolInfoDouble(InpSymbol, SYMBOL_VOLUME_MIN);
   double maxv = SymbolInfoDouble(InpSymbol, SYMBOL_VOLUME_MAX);
   double step = SymbolInfoDouble(InpSymbol, SYMBOL_VOLUME_STEP);
   volume = MathMax(minv, MathMin(maxv, volume));
   if(step > 0) volume = MathFloor(volume / step) * step;
   return NormalizeDouble(volume, 2);
}

bool HasOurPosition()
{
   for(int i=PositionsTotal()-1; i>=0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && PositionGetString(POSITION_SYMBOL) == InpSymbol &&
         (int)PositionGetInteger(POSITION_MAGIC) == InpMagic) return true;
   }
   return false;
}

double TodayClosedProfit()
{
   MqlDateTime dt; TimeToStruct(TimeCurrent(), dt);
   dt.hour=0; dt.min=0; dt.sec=0;
   if(!HistorySelect(StructToTime(dt), TimeCurrent())) return 0;
   double total=0;
   for(int i=HistoryDealsTotal()-1; i>=0; i--)
   {
      ulong deal=HistoryDealGetTicket(i);
      if(deal==0) continue;
      if(HistoryDealGetString(deal, DEAL_SYMBOL)==InpSymbol &&
         (int)HistoryDealGetInteger(deal, DEAL_MAGIC)==InpMagic)
         total += HistoryDealGetDouble(deal, DEAL_PROFIT)
                + HistoryDealGetDouble(deal, DEAL_SWAP)
                + HistoryDealGetDouble(deal, DEAL_COMMISSION);
   }
   return total;
}

void PollControl()
{
   string response;
   if(HttpGet("/control", response))
      tradingEnabled = JsonEnabled(response);
}

void PublishStatus(string signal, string message)
{
   string body = StringFormat(
      "{\"symbol\":\"%s\",\"balance\":%.2f,\"equity\":%.2f,\"profit\":%.2f,\"last_signal\":\"%s\",\"message\":\"%s\"}",
      InpSymbol, AccountInfoDouble(ACCOUNT_BALANCE), AccountInfoDouble(ACCOUNT_EQUITY),
      AccountInfoDouble(ACCOUNT_PROFIT), signal, message);
   string response;
   HttpPost("/status", body, response);
}

void CheckSignal()
{
   if(!tradingEnabled) return;
   if(InpDemoOnly && AccountInfoInteger(ACCOUNT_TRADE_MODE) != ACCOUNT_TRADE_MODE_DEMO)
   { PublishStatus("BLOCKED","DEMO only: live account blocked"); return; }

   MqlDateTime dt; TimeToStruct(TimeCurrent(), dt);
   if(dayOfYear != dt.day_of_year)
   {
      dayOfYear = dt.day_of_year;
      dayStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
   }
   if(dayStartEquity - AccountInfoDouble(ACCOUNT_EQUITY) >= InpDailyLossLimit)
   { tradingEnabled=false; PublishStatus("BLOCKED","Daily loss limit reached"); return; }

   if(HasOurPosition()) return;
   MqlTick tick;
   if(!SymbolInfoTick(InpSymbol, tick)) return;
   double point = SymbolInfoDouble(InpSymbol, SYMBOL_POINT);
   if(point <= 0 || (tick.ask-tick.bid)/point > InpMaxSpreadPoints) return;

   datetime bar = iTime(InpSymbol, PERIOD_M1, 0);
   if(bar == 0 || bar == lastBar) return;
   lastBar = bar;

   double f[3], s[3];
   ArraySetAsSeries(f,true); ArraySetAsSeries(s,true);
   if(CopyBuffer(fastHandle,0,0,3,f)<3 || CopyBuffer(slowHandle,0,0,3,s)<3) return;

   bool buy = (f[2] <= s[2] && f[1] > s[1]);
   bool sell = (f[2] >= s[2] && f[1] < s[1]);
   if(!buy && !sell) return;

   double vol = NormalizeVolume(InpLots);
   double tpDist = MoneyToPriceDistance(InpTakeProfitMoney, vol);
   double slDist = MoneyToPriceDistance(InpStopLossMoney, vol);
   if(tpDist<=0 || slDist<=0) { PublishStatus("ERROR","Cannot calculate SL/TP from symbol tick specs"); return; }

   trade.SetExpertMagicNumber(InpMagic);
   trade.SetDeviationInPoints(20);
   bool ok=false;
   if(buy)
      ok = trade.Buy(vol, InpSymbol, 0, NormalizeDouble(tick.ask-slDist,_Digits),
                     NormalizeDouble(tick.ask+tpDist,_Digits), "GoldBot DEMO BUY");
   else
      ok = trade.Sell(vol, InpSymbol, 0, NormalizeDouble(tick.bid+slDist,_Digits),
                      NormalizeDouble(tick.bid-tpDist,_Digits), "GoldBot DEMO SELL");

   PublishStatus(ok ? (buy ? "BUY" : "SELL") : "ORDER_FAILED",
                 ok ? "Order sent; verify broker execution" : trade.ResultRetcodeDescription());
}

int OnInit()
{
   if(!SymbolSelect(InpSymbol,true)) { Print("Cannot select symbol ",InpSymbol); return INIT_FAILED; }
   fastHandle=iMA(InpSymbol,PERIOD_M1,InpFastEMA,0,MODE_EMA,PRICE_CLOSE);
   slowHandle=iMA(InpSymbol,PERIOD_M1,InpSlowEMA,0,MODE_EMA,PRICE_CLOSE);
   if(fastHandle==INVALID_HANDLE || slowHandle==INVALID_HANDLE) return INIT_FAILED;
   EventSetTimer(InpPollSeconds);
   trade.SetExpertMagicNumber(InpMagic);
   Print("GoldBot Mobile DEMO EA initialized. Confirm DEMO account and WebRequest URL.");
   return INIT_SUCCEEDED;
}

void OnTimer()
{
   PollControl();
   PublishStatus("NONE", tradingEnabled ? "Bot enabled" : "Bot stopped");
}

void OnTick() { CheckSignal(); }

void OnDeinit(const int reason)
{
   EventKillTimer();
   if(fastHandle!=INVALID_HANDLE) IndicatorRelease(fastHandle);
   if(slowHandle!=INVALID_HANDLE) IndicatorRelease(slowHandle);
}
