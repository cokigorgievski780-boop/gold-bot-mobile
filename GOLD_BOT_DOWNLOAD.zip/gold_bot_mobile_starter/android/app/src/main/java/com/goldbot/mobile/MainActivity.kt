package com.goldbot.mobile

import android.app.Activity
import android.os.Bundle
import android.widget.*
import android.graphics.Typeface
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    // Configure these for your HTTPS VPS endpoint. Do not publish this demo API key.
    private val baseUrl = "https://YOUR-DOMAIN.example"
    private val apiKey = "PASTE_LONG_RANDOM_DEMO_KEY_HERE"
    private lateinit var status: TextView
    private lateinit var balance: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 24)
        }
        val title = TextView(this).apply {
            text = "GOLD BOT MOBILE"
            textSize = 25f
            setTypeface(null, Typeface.BOLD)
        }
        status = TextView(this).apply { text = "Status: connecting…"; textSize = 18f }
        balance = TextView(this).apply { text = "Balance: —"; textSize = 22f }
        val start = Button(this).apply { text = "START BOT"; setOnClickListener { command("start") } }
        val stop = Button(this).apply { text = "STOP BOT"; setOnClickListener { command("stop") } }
        val refresh = Button(this).apply { text = "REFRESH"; setOnClickListener { refreshStatus() } }
        layout.addView(title); layout.addView(status); layout.addView(balance)
        layout.addView(start); layout.addView(stop); layout.addView(refresh)
        setContentView(layout)
        refreshStatus()
    }

    private fun request(path: String, method: String = "GET", callback: (String) -> Unit) {
        thread {
            try {
                val conn = (URL(baseUrl + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    connectTimeout = 5000
                    readTimeout = 5000
                    setRequestProperty("X-API-Key", apiKey)
                    if (method == "POST") doOutput = true
                }
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                runOnUiThread { callback(response) }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Connection error: ${e.message}" }
            }
        }
    }

    private fun command(action: String) {
        request("/control/$action", "POST") {
            status.text = "Command sent: $action. Confirm MT5 Experts/Journal."
            refreshStatus()
        }
    }

    private fun refreshStatus() {
        request("/status") { body ->
            status.text = body
            val regex = Regex("\"balance\"\\s*:\\s*([0-9.]+)")
            balance.text = "Balance: " + (regex.find(body)?.groupValues?.get(1) ?: "—")
        }
    }
}
