# Android build

1. Инсталирај Android Studio на компјутер (за прво компајлирање е потребен компјутер).
2. Отвори го `android` директориумот како проект.
3. Во `MainActivity.kt` постави го HTTPS доменот и DEMO API key.
4. Sync Gradle → Build → Build APK(s).
5. APK се појавува во `app/build/outputs/apk/debug/`.

Во моментов не може да се направи/компајлира APK само од Android телефон со овој пакет. Може да го зачуваш изворниот код на телефонот, но за build е потребна компатибилна Android build околина.
